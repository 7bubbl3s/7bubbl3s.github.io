Ciao compatriota!
Sono @7bubbl3s , uno youtuber, themer, e appassionato ed esperto di jailbreak di iOS e ho sviluppato questa traduzione IN ITALIANO per l'app Tweetbot 4, sviluppata dai @tapbots!
RINGRAZIO IL TEAM BITEYOURAPPLE PER AVER HOSTATO IN ESCLUSIVA QUESTO PACCHETTO.
Ma come applicarla all'app?
Non è necessario avere il jailbreak, però se si possiede un dispositivo sbloccato la procedura sarà molto più rapida e semplice.
Puoi eseguire il jailbreak di iOS 9.0.x col tool Pangu9.
Ricorda però che, in entrambi i casi, ogni volta che aggiornerai l'app Tweetbot 4, dovrai ripetere la procedura di inserimento della traduzione.

Se NON hai il jailbreak:
Segui questo video: (uscirà a breve)

Se invece hai il jailbreak:
- apri Cydia e scarica l'app iFile;
- trasferisci questo file .zip all'interno del tuo dispositivo iOS jailbroken (ti consiglio nella directory /var/mobile) ed estraine il contenuto (premi su di esso e poi seleziona "Estrazione"); (SE HAI SCARICATO DA CYDIA IL FILE SARÀ GIÀ ESTRATTO)
- in basso a sinistra, premi sull'iconcina dell'ingranaggio che ti porterà alle impostazioni di iFile: seleziona "Gestore file" e assicurati che la voce "Nomi applicazioni" sia abilitata;
- copia la cartella Italian.lproj
- vai nella directory /var/mobile/Containers/Bundle/Application/Tweetbot/Tweetbot.app
E incolla la cartella;
- assicurati di aver chiuso Tweetbot 4 nello switcher;
- ora apri Tweetbot 4 e sarà completamente in italiano!

Spero che la mia traduzione ti sia piaciuta e che ti sia stata utile :) Se vuoi farmi una donazione la mia mail PayPal è darklightunsparkle@live.it
Supportandomi i miei progetti andranno sempre avanti e magari potrei in futuro comprare qualche nuovo iDevice per fare test o video sul mio canale YouTube 7bubbl3s 4S di cui lascio anche il link:
https://m.youtube.com/channel/UCi49NudUz53Ci16vXWKwjEQ
Inoltre in questo mio video sono linkate un sacco di vecchie versioni di app in formato IPA per vecchie versioni di iOS (specialmente di iOS 6, che ho sul mio bellissimo iPhone 4S). Eccoti il link:
http://youtu.be/mZNPJGSIl2A
Se vuoi puoi seguirmi su Twitter, il mio username è @7bubbl3s . Scrivimi se vuoi segnalarmi qualche errore/bug, se vuoi farmi qualche richiesta o se semplicemente vuoi fare quattro chiacchiere con me.
Inoltre puoi anche parlarmi su Telegram, non devi fare altro che andare nella barra di ricerca in alto e digitare @sevenbubbl3s e potrai chattare con me.
Non dimenticare di aggiungere la mia repo personale su Cydia!
http://7bubbl3s.github.io
Ciao :)

Tweetbot 4 has been developed by @tapbots
Translated in Italian by @7bubbl3s
Hosted by @BiteYourApple
http://repo.biteyourapple.net